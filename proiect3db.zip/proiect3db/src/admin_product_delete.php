<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$productId = $_GET['id'] ?? '';

// Încarcă datele produsului
$productData = null;
$xml = simplexml_load_file('data/products.xml');
foreach ($xml->product as $product) {
    if ((string)$product['id'] === $productId) {
        $productData = [
            'name' => (string)$product->name,
            'image' => isset($product->image) ? (string)$product->image : ''
        ];
        break;
    }
}

if (!$productData) {
    header('Location: admin_products.php');
    exit();
}

// Procesează ștergerea
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Șterge imaginea dacă există
    if ($productData['image'] && file_exists($productData['image'])) {
        unlink($productData['image']);
    }

    // Șterge produsul din XML
    $products = $xml->xpath("/products/product[@id!='$productId']");
    
    $newXml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><products></products>');
    foreach ($products as $product) {
        $newProduct = $newXml->addChild('product');
        $newProduct->addAttribute('id', (string)$product['id']);
        foreach ($product->children() as $child) {
            $newProduct->addChild($child->getName(), (string)$child);
        }
    }

    // Salvează în fișier
    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($newXml->asXML());
    
    if ($dom->save('data/products.xml')) {
        $_SESSION['success'] = 'Produs șters cu succes!';
    } else {
        $_SESSION['error'] = 'Eroare la ștergerea produsului!';
    }
    
    header('Location: admin_products.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Șterge Produs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php include('admin_nav.php'); ?>

    <main class="container-fluid py-4">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h2 class="h4 mb-0"><i class="bi bi-exclamation-triangle text-danger"></i> Confirmă ștergerea</h2>
                    </div>
                    <div class="card-body">
                        <p>Ești sigur că vrei să ștergi produsul <strong><?= htmlspecialchars($productData['name']) ?></strong>?</p>
                        <p class="text-danger">Atenție: Această acțiune este permanentă și nu poate fi anulată!</p>
                        
                        <?php if ($productData['image']): ?>
                        <div class="alert alert-warning">
                            <i class="bi bi-info-circle"></i> Fișierul imagine asociat va fi șters: 
                            <code><?= htmlspecialchars(basename($productData['image'])) ?></code>
                        </div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="d-flex justify-content-between">
                                <a href="admin_products.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-x-circle"></i> Anulează
                                </a>
                                <button type="submit" class="btn btn-danger">
                                    <i class="bi bi-trash"></i> Șterge Produs
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>