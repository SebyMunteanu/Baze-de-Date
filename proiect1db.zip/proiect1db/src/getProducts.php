<?php
require_once 'connection.php';
###
try{
$sql1="DROP PROCEDURE IF EXISTS getProducts";
$sql2="CREATE PROCEDURE getProducts(
    IN intID INT,
    OUT strNume VARCHAR(30),
    OUT strDetalii VARCHAR(30),
    OUT intPret INT,
    OUT strImagine VARCHAR(255)
)
BEGIN
    SELECT nume, detalii, pret , imagine
    INTO strNume, strDetalii, intPret ,strImagine
    FROM products 
    WHERE id = intID;
END";
$stmt1=$con->prepare($sql1);
$stmt2=$con->prepare($sql2);
$stmt1->execute();
$stmt2->execute();
}catch(PDOException $e){
    die ("Error creating stored procedure: " . $e->getMessage());
}
###

if ($_SERVER['REQUEST_METHOD'] === 'POST'&& isset($_POST['id'])) {
    $id = $_POST['id'];
    try{
        // Apelam procedura stocata
        $sql1="CALL getProducts(:id, @out_nume, @out_detalii, @out_pret ,@out_imagine)";
        $sql2="SELECT @out_nume AS nume, @out_detalii AS detalii , @out_pret AS pret , @out_imagine AS imagine";
        $stmt1=$con->prepare($sql1);
        $stmt1->execute([':id' => $id]);

        $stmt2=$con->prepare($sql2);
        $stmt2->execute();
        $stmt2->setFetchMode(PDO::FETCH_ASSOC);
        // Afisarea rezultatelor
        $row=$stmt2->fetch();
        if ($row) {
            echo "<table border='1'>
                    <tr>
                        <th>Nume</th>
                        <th>Detalii</th>
                        <th>Pret</th>
                        <th>Imagine</th>
                    </tr>
                    <tr>
                        <td>" . htmlspecialchars($row['nume'] ?? 'N/A') . "</td>
                        <td>" . htmlspecialchars($row['detalii'] ?? 'N/A') . "</td>
                        <td>" . htmlspecialchars($row['pret'] ?? 'N/A') . "</td>
                        <td>";
            
            // Verifică dacă există o imagine și o afișează
            if (!empty($row['imagine'])) {
                echo "<img src='" . htmlspecialchars($row['imagine']) . "' alt='Imagine produs' style='max-width: 100px;'>";
            } else {
                echo "Fără imagine";
            }
        
            echo "</td>
                  </tr>
                  </table>";
        } else {
            echo "<div class='alert alert-warning'>No product found with ID = $id</div>";
        }
    } catch (PDOException $e) {
        echo "<div class='alert alert-danger'>Error fetching data: " . $e->getMessage() . "</div>";
    }
    
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Get Product by ID</title>
    <!-- Stiluri Bootstrap pentru un aspect mai frumos -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Get Product by ID</h1>
        <form action="getProducts.php" method="POST" class="mt-4">
            <div class="mb-3">
                <label for="id" class="form-label">Product ID:</label>
                <input type="number" name="id" id="id" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary">Get Product</button>
        </form>
        <br/>
        <a href="index.php" class="btn btn-secondary">Back to Home</a>
    </div>

    <!-- Scripturi Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>