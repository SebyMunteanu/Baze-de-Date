<?php
session_start();

// Verifică dacă utilizatorul este logat și admin
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

if ($_SESSION['user']['role'] !== 'admin') {
    header('Location: index.php');
    exit();
}

// Funcții pentru obținerea datelor reale
function getTotalUsers() {
    if (file_exists('data/users.xml')) {
        $xml = simplexml_load_file('data/users.xml');
        return count($xml->user);
    }
    return 0;
}

function getTotalProducts() {
    if (file_exists('data/products.xml')) {
        $xml = simplexml_load_file('data/products.xml');
        return count($xml->product);
    }
    return 0;
}

function getRecentOrders() {
    // Aici poți adăuga logica pentru comenzi dacă ai un fișier orders.xml
    return [
        ['date' => date('Y-m-d'), 'user' => 'client1', 'action' => 'Comandă nouă', 'details' => 'Produse: 3'],
        ['date' => date('Y-m-d', strtotime('-1 day')), 'user' => 'client2', 'action' => 'Comandă finalizată', 'details' => 'Total: 150 lei']
    ];
}

// Obține date reale
$totalUsers = getTotalUsers();
$totalProducts = getTotalProducts();
$recentOrders = getRecentOrders();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #212529;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
            border-radius: 5px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.2);
        }
        .stat-card {
            transition: transform 0.3s;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse bg-dark p-3">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h4 class="text-white">Admin Panel</h4>
                        <hr class="bg-light">
                        <p class="text-muted small">Bun venit, <strong><?= htmlspecialchars($_SESSION['user']['username']) ?></strong></p>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="admin.php">
                                <i class="bi bi-speedometer2 me-2"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_users.php">
                                <i class="bi bi-people me-2"></i>Utilizatori
                                <span class="badge bg-primary float-end"><?= $totalUsers ?></span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_products.php">
                                <i class="bi bi-box-seam me-2"></i>Produse
                                <span class="badge bg-success float-end"><?= $totalProducts ?></span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_orders.php">
                                <i class="bi bi-receipt me-2"></i>Comenzi
                                <span class="badge bg-warning float-end"><?= count($recentOrders) ?></span>
                            </a>
                        </li>
                        <li class="nav-item mt-4">
                            <a class="nav-link text-danger" href="logout.php">
                                <i class="bi bi-box-arrow-right me-2"></i>Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary">Export Date</button>
                        </div>
                        <span class="text-muted"><?= date('d F Y') ?></span>
                    </div>
                </div>

                <!-- Stat Cards -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="stat-card card text-white bg-primary h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Utilizatori</h5>
                                        <h2 class="card-text"><?= $totalUsers ?></h2>
                                    </div>
                                    <i class="bi bi-people display-6 opacity-50"></i>
                                </div>
                                <a href="admin_users.php" class="text-white small">Vezi detalii <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stat-card card text-white bg-success h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Produse</h5>
                                        <h2 class="card-text"><?= $totalProducts ?></h2>
                                    </div>
                                    <i class="bi bi-box-seam display-6 opacity-50"></i>
                                </div>
                                <a href="admin_products.php" class="text-white small">Vezi detalii <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="stat-card card text-white bg-warning h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Comenzi</h5>
                                        <h2 class="card-text"><?= count($recentOrders) ?></h2>
                                    </div>
                                    <i class="bi bi-receipt display-6 opacity-50"></i>
                                </div>
                                <a href="admin_orders.php" class="text-white small">Vezi detalii <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Ultimele activități -->
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Ultimele activități</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Data</th>
                                        <th>Utilizator</th>
                                        <th>Acțiune</th>
                                        <th>Detalii</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentOrders as $order): ?>
                                    <tr>
                                        <td><?= $order['date'] ?></td>
                                        <td><?= $order['user'] ?></td>
                                        <td><?= $order['action'] ?></td>
                                        <td><?= $order['details'] ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Activează tooltip-urile
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    </script>
</body>
</html>