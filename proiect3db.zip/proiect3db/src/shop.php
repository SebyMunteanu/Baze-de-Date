<?php
// shop.php
session_start();

// Redirecționează dacă nu ești autentificat ca user
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
    header('Location: login.php');
    exit();
}

// Încarcă produsele
$products = [];
if (file_exists('data/products.xml')) {
    $xml = simplexml_load_file('data/products.xml');
    foreach ($xml->product as $product) {
        $products[] = [
            'id' => (string)$product['id'],
            'name' => (string)$product->name,
            'price' => (float)$product->price,
            'image' => (string)$product->image
        ];
    }
}

// Adaugă în coș dacă a fost trimis un produs
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $id = $_POST['product_id'];
    $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
    header('Location: shop.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Magazin - Client</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    .card {
        height: 100%;
        display: flex;
        flex-direction: column;
    }

    .card-img-top {
        height: 200px;
        object-fit: contain;
        padding: 10px;
    }

    .card-body {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        flex-grow: 1;
    }

    .card-title {
        font-size: 1.2rem;
        font-weight: bold;
        min-height: 3rem; /* rezervă spațiu fix pt titlu */
    }

    .card-text {
        min-height: 2rem; /* rezervă spațiu pt preț */
    }

    .card .d-flex {
        margin-top: auto; /* împinge butoanele jos */
    }
    </style>
</head>
<body class="container py-4">
    <h1 class="mb-4">Produse disponibile</h1>
    <a href="logout.php" class="btn btn-outline-danger float-end">Logout</a>
    <a href="cart.php" class="btn btn-primary mb-3">🛒 Vezi coșul</a>
    <div class="row">
        <?php foreach ($products as $product): ?>
        <div class="col-md-4">
            <div class="card mb-4">
                <img src="<?= htmlspecialchars($product['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                    <p class="card-text">Preț: <?= number_format($product['price'], 2) ?> lei</p>
                    <div class="d-flex justify-content-between">
                        <form method="post">
                            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                            <button type="submit" class="btn btn-success btn-sm">Adaugă în coș</button>
                        </form>
                        <a href="product_view.php?id=<?= $product['id'] ?>" class="btn btn-outline-secondary btn-sm">Vezi detalii</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
