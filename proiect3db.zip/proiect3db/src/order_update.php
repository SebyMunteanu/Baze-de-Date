<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$orderId = $_GET['id'] ?? null;
$action = $_GET['action'] ?? null;

if (!$orderId || $action !== 'finalizeaza') {
    header('Location: admin_orders.php');
    exit();
}

$ordersFile = 'data/orders.xml';

if (file_exists($ordersFile)) {
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->load($ordersFile);

    $xpath = new DOMXPath($dom);
    $orderNode = $xpath->query("//order[@id='$orderId']")->item(0);

    if ($orderNode) {
        $orderNode->setAttribute('status', 'finalizată');
        $dom->save($ordersFile);
    }
}

header('Location: admin_orders.php');
exit();
