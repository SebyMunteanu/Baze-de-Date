<?php
require_once 'connection.php';

$searchTerm = $_POST['nume'] ?? '';
$filter = ['nume' => ['$regex' => $searchTerm, '$options' => 'i']]; // Căutare case-insensitive
$query = new MongoDB\Driver\Query($filter);
$products = $client->executeQuery("my_shop_db.products", $query);
$productList = iterator_to_array($products);

// Verifică existența fișierelor pentru fiecare produs
foreach ($productList as $product) {
    if (!empty($product->imagine)) {
        $product->imageExists = file_exists('uploads/' . $product->imagine);
    } else {
        $product->imageExists = false;
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Rezultate Căutare - <?= htmlspecialchars($searchTerm) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <style>
        .search-header {
            background-color: #f8f9fa;
            border-radius: 0.5rem;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .product-card {
            transition: transform 0.2s;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .no-results {
            min-height: 50vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .product-image {
            height: 200px;
            object-fit: contain;
            padding: 1rem;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-shop"></i> Magazinul Meu
            </a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="bi bi-arrow-left"></i> Înapoi la magazin
                        </a>
                    </li>
                </ul>
                <form class="d-flex" method="post" action="search.php">
                    <div class="input-group">
                        <input class="form-control" type="search" name="nume" 
                               value="<?= htmlspecialchars($searchTerm) ?>" 
                               placeholder="Caută produse..." required>
                        <button class="btn btn-outline-primary" type="submit">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </nav>

    <!-- Search Results Section -->
    <main class="py-5">
        <div class="container px-4 px-lg-5">
            <div class="search-header text-center mb-5">
                <h1 class="display-6 fw-bold">
                    <i class="bi bi-search-heart"></i> Rezultate căutare
                </h1>
                <p class="lead">Am găsit <?= count($productList) ?> rezultate pentru "<?= htmlspecialchars($searchTerm) ?>"</p>
            </div>

            <?php if (!empty($productList)): ?>
                <div class="row gx-4 gx-lg-5 row-cols-1 row-cols-md-2 row-cols-xl-3">
                    <?php foreach ($productList as $product): ?>
                        <div class="col mb-5">
                            <div class="card h-100 product-card">
                                <!-- Product image-->
                                <img class="card-img-top product-image" 
                                    src="<?= (!empty($product->imagine) && $product->imageExists) ? 'uploads/' . $product->imagine : 'https://via.placeholder.com/300x200?text=No+Image' ?>" 
                                    alt="<?= htmlspecialchars($product->nume) ?>"
                                    onerror="this.src='https://via.placeholder.com/300x200?text=Image+Not+Found'">

                                
                                <!-- Product details-->
                                <div class="card-body p-4">
                                    <div class="text-center">
                                        <!-- Product name-->
                                        <h3 class="fw-bolder"><?= htmlspecialchars($product->nume) ?></h3>
                                        <!-- Product details-->
                                        <div class="mt-3">
                                            <?php if (!empty($product->culoare)): ?>
                                                <span class="badge bg-primary me-1"><?= htmlspecialchars($product->culoare) ?></span>
                                            <?php endif; ?>
                                            <?php if (!empty($product->marime)): ?>
                                                <span class="badge bg-secondary me-1"><?= htmlspecialchars($product->marime) ?></span>
                                            <?php endif; ?>
                                            <?php if (!empty($product->age)): ?>
                                                <span class="badge bg-info"><?= htmlspecialchars($product->age) ?> ani</span>
                                            <?php endif; ?>
                                        </div>
                                        <!-- Product price-->
                                        <div class="fs-3 my-3 text-danger">
                                            <?= htmlspecialchars($product->pret) ?> RON
                                        </div>
                                    </div>
                                </div>
                                <!-- Product actions-->
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center">
                                        <a class="btn btn-outline-dark mt-auto" href="view.php?id=<?= $product->_id ?>">
                                            <i class="bi bi-eye"></i> Vezi detalii
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="no-results">
                    <div class="text-center py-5">
                        <i class="bi bi-search-x fs-1 text-muted"></i>
                        <h2 class="fw-bold text-muted mt-3">Nu s-au găsit rezultate</h2>
                        <p class="lead">Încercați alt termen de căutare</p>
                        <a href="index.php" class="btn btn-primary mt-3">
                            <i class="bi bi-house-door"></i> Înapoi la magazin
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="py-4 bg-dark">
        <div class="container">
            <p class="m-0 text-center text-white">
                &copy; <?= date('Y') ?> Magazinul Meu. Toate drepturile rezervate.
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>