<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';
$productId = $_GET['id'] ?? '';

// Încarcă datele produsului
$productData = null;
$xml = simplexml_load_file('data/products.xml');
foreach ($xml->product as $product) {
    if ((string)$product['id'] === $productId) {
        $productData = [
            'id' => (string)$product['id'],
            'name' => (string)$product->name,
            'price' => (float)$product->price,
            'category' => (string)$product->category,
            'stock' => (int)$product->stock,
            'description' => (string)$product->description,
            'image' => isset($product->image) ? (string)$product->image : ''
        ];
        break;
    }
}

if (!$productData) {
    header('Location: admin_products.php');
    exit();
}

// Procesează formularul
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $price = (float)$_POST['price'];
    $category = trim($_POST['category']);
    $stock = (int)$_POST['stock'];
    $description = trim($_POST['description']);
    $removeImage = isset($_POST['remove_image']);

    // Procesează imaginea
    $imagePath = $productData['image'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'assets/products/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // Șterge vechea imagine dacă există
        if ($imagePath && file_exists($imagePath)) {
            unlink($imagePath);
        }

        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $destination = $uploadDir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
            $imagePath = $destination;
        } else {
            $error = 'Eroare la încărcarea imaginii!';
        }
    } elseif ($removeImage && $imagePath) {
        // Șterge imaginea existentă
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
        $imagePath = '';
    }

    if (!$error) {
        // Actualizează produsul în XML
        foreach ($xml->product as $product) {
            if ((string)$product['id'] === $productId) {
                $product->name = htmlspecialchars($name);
                $product->price = $price;
                $product->category = htmlspecialchars($category);
                $product->stock = $stock;
                $product->description = htmlspecialchars($description);
                
                // Actualizează imaginea
                if (isset($product->image)) {
                    if ($imagePath) {
                        $product->image = $imagePath;
                    } else {
                        unset($product->image[0]);
                    }
                } elseif ($imagePath) {
                    $product->addChild('image', $imagePath);
                }
                
                break;
            }
        }

        // Salvează XML
        $dom = new DOMDocument('1.0');
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;
        $dom->loadXML($xml->asXML());
        
        if ($dom->save('data/products.xml')) {
            $success = 'Produs actualizat cu succes!';
            $productData['name'] = $name;
            $productData['price'] = $price;
            $productData['category'] = $category;
            $productData['stock'] = $stock;
            $productData['description'] = $description;
            $productData['image'] = $imagePath;
        } else {
            $error = 'Eroare la salvarea produsului!';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editează Produs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .image-preview-container {
            margin-top: 15px;
        }
        .image-preview {
            max-width: 200px;
            max-height: 200px;
            display: block;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php include('admin_nav.php'); ?>

    <main class="container-fluid py-4">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h2 class="h4 mb-0"><i class="bi bi-pencil-square"></i> Editează Produs</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php elseif ($success): ?>
                            <div class="alert alert-success"><?= $success ?></div>
                        <?php endif; ?>

                        <form method="POST" enctype="multipart/form-data">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="name" class="form-label">Nume Produs</label>
                                    <input type="text" class="form-control" id="name" name="name" 
                                           value="<?= htmlspecialchars($productData['name']) ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="price" class="form-label">Preț (RON)</label>
                                    <input type="number" step="0.01" class="form-control" id="price" name="price" 
                                           value="<?= $productData['price'] ?>" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="category" class="form-label">Categorie</label>
                                    <select class="form-select" id="category" name="category" required>
                                        <option value="Electronice" <?= $productData['category'] === 'Electronice' ? 'selected' : '' ?>>Electronice</option>
                                        <option value="Fashion" <?= $productData['category'] === 'Fashion' ? 'selected' : '' ?>>Fashion</option>
                                        <option value="Casă" <?= $productData['category'] === 'Casă' ? 'selected' : '' ?>>Casă</option>
                                        <option value="Jucării" <?= $productData['category'] === 'Jucării' ? 'selected' : '' ?>>Jucării</option>
                                        <option value="Altele" <?= $productData['category'] === 'Altele' ? 'selected' : '' ?>>Altele</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="stock" class="form-label">Stoc</label>
                                    <input type="number" class="form-control" id="stock" name="stock" 
                                           value="<?= $productData['stock'] ?>" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">Descriere</label>
                                <textarea class="form-control" id="description" name="description" rows="3"><?= 
                                    htmlspecialchars($productData['description']) ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Imagine Produs</label>
                                
                                <?php if ($productData['image']): ?>
                                <div class="image-preview-container">
                                    <img src="<?= $productData['image'] ?>" alt="Imagine produs" class="image-preview">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="remove_image" name="remove_image">
                                        <label class="form-check-label text-danger" for="remove_image">
                                            Șterge imaginea existentă
                                        </label>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <input type="file" class="form-control mt-2" id="image" name="image" accept="image/*">
                                <small class="text-muted">Încarcă o nouă imagine (JPEG, PNG, max 2MB)</small>
                            </div>

                            <div class="d-flex justify-content-between">
                                <a href="admin_products.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-arrow-left"></i> Înapoi
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save"></i> Salvează Modificări
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>