<?php
require_once 'connection.php';
$bulk = new MongoDB\Driver\BulkWrite;

if (!isset($_POST["submit"])) {
    $id = new \MongoDB\BSON\ObjectId($_GET['id']);
    $filter = ['_id' => $id];
    $query = new MongoDB\Driver\Query($filter);
    $article = $client->executeQuery("my_shop_db.products", $query);
    $doc = current($article->toArray());
} else {
    $data = [
        'nume' => $_POST['nume'],
        'culoare' => $_POST['culoare'],
        'marime' => $_POST['marime'],
        'pret' => $_POST['pret']
    ];
    
    if (!empty($_FILES["imagine"]["name"])) {
        $targetDir = "uploads/";
        $fileName = basename($_FILES["imagine"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

        $allowTypes = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($fileType, $allowTypes)) {
            if (move_uploaded_file($_FILES["imagine"]["tmp_name"], $targetFilePath)) {
                $data['imagine'] = $fileName;
            } else {
                echo "Eroare la încărcarea imaginii.";
                exit;
            }
        } else {
            echo "Doar fișiere JPG, JPEG, PNG și GIF sunt permise.";
            exit;
        }
    }

    $id = new \MongoDB\BSON\ObjectId($_POST['id']);
    $filter = ['_id' => $id];
    $update = ['$set' => $data];

    $bulk->update($filter, $update);
    $client->executeBulkWrite('my_shop_db.products', $bulk);
    
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Editare Produs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <style>
        .edit-container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 0.5rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="index.php">My Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item"><a class="nav-link" href="index.php">Back to Shop</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="py-5">
        <div class="container">
            <div class="edit-container">
                <h1 class="mb-4 text-center"><i class="bi bi-pencil-square"></i> Update Products</h1>
                
                <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $doc->_id; ?>">
                    
                    <div class="mb-3">
                        <label for="nume" class="form-label">Products Name</label>
                        <input type="text" class="form-control" id="nume" name="nume" value="<?php echo htmlspecialchars($doc->nume); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Imaginea Actuală:</label><br>
                        <?php if (!empty($doc->imagine)): ?>
                            <img src="uploads/<?php echo htmlspecialchars($doc->imagine); ?>" class="img-thumbnail" style="max-width: 200px;">
                        <?php else: ?>
                            <p class="text-muted">Nicio imagine încă.</p>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="imagine" class="form-label">Încarcă o nouă imagine</label>
                        <input type="file" class="form-control" id="imagine" name="imagine">
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="culoare" class="form-label">Color</label>
                            <input type="text" class="form-control" id="culoare" name="culoare" value="<?php echo htmlspecialchars($doc->culoare); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="marime" class="form-label">Size</label>
                            <input type="text" class="form-control" id="marime" name="marime" value="<?php echo htmlspecialchars($doc->marime); ?>">
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label for="pret" class="form-label">Price (RON)</label>
                        <div class="input-group">
                            <span class="input-group-text">RON</span>
                            <input type="number" step="0.01" class="form-control" id="pret" name="pret" value="<?php echo htmlspecialchars($doc->pret); ?>" required>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="index.php" class="btn btn-outline-secondary me-md-2">
                            <i class="bi bi-arrow-left"></i> Renunță
                        </a>
                        <button type="submit" name="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> Salvează modificările
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</body>
</html>