<?php
// Încărcare produse din XML (simplificat)
$products = [];
if (file_exists('data/products.xml')) {
    $xml = simplexml_load_file('data/products.xml');
    foreach ($xml->product as $product) {
        $products[] = [
            'id' => (string)$product['id'],
            'name' => (string)$product->name,
            'price' => (float)$product->price,
            'image' => isset($product->image) ? (string)$product->image : 'assets/placeholder.jpg',
            'category' => (string)$product->category
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Shop Homepage</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
        <style>
            /* Stiluri existente pentru produse */
            .product-card {
                transition: all 0.3s ease;
                height: 100%;
            }
            .product-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            }
            .product-img {
                height: 200px;
                object-fit: contain;
                padding: 15px;
            }
            .price-text {
                font-size: 1.1rem;
                font-weight: bold;
            }
            
            /* Stiluri noi pentru header */
            .header-math {
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 2rem;
                margin-bottom: 1.5rem;
            }
            .math-formula {
                font-size: 1.8rem;
                color: #fff;
                background: rgba(255,255,255,0.15);
                padding: 0.8rem;
                border-radius: 0.5rem;
            }
            .header-svg {
                width: 80px;
                height: 80px;
            }
        </style>
    </head>
    <body>
        <!-- Navigation (nemodificat) -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="index.php">Proiect 3</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Shop</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#!">All Products</a></li>
                                <li><hr class="dropdown-divider" /></li>
                                <?php
                                $categories = [];
                                foreach ($products as $product) {
                                    if (!in_array($product['category'], $categories)) {
                                        $categories[] = $product['category'];
                                        echo '<li><a class="dropdown-item" href="#'.$product['category'].'">'.$product['category'].'</a></li>';
                                    }
                                }
                                ?>
                            </ul>
                        </li>
                    </ul>
                    <div class="d-flex">
                        <a href="login.php" class="btn btn-outline-primary me-2">
                            <i class="bi bi-box-arrow-in-right me-1"></i>
                            Login
                        </a>
                        <button class="btn btn-outline-dark" type="submit">
                            <i class="bi-cart-fill me-1"></i>
                            Cart
                            <span class="badge bg-dark text-white ms-1 rounded-pill">0</span>
                        </button>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Header modificat -->
        <header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="header-math">
                    
                    <!-- Formula matematica -->
                    <div class="math-formula">
                        <math xmlns="http://www.w3.org/1998/Math/MathML">
                            <msup><mi>a</mi><mn>2</mn></msup>
                            <mo>+</mo>
                            <msup><mi>b</mi><mn>2</mn></msup>
                            <mo>=</mo>
                            <msup><mi>c</mi><mn>2</mn></msup>
                        </math>
                    </div>
                    
                    <!-- Titlu -->
                    <div class="text-center text-white">
                        <h1 class="display-4 fw-bolder">Shop</h1>
                        <p class="lead fw-normal text-white-50 mb-0">-</p>
                    </div>
                    
                    <!-- SVG -->
                    <div class="header-svg">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
                            <circle cx="50" cy="50" r="45" fill="none" stroke="#fff" stroke-width="3"/>
                            <path d="M35,35 L65,65 M35,65 L65,35" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
                        </svg>
                    </div>
                </div>
            </div>
        </header>

        
        <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <?php foreach ($products as $product): ?>
                    <div class="col mb-5">
                        <div class="card h-100 product-card">
                            <img class="card-img-top product-img" src="<?= $product['image'] ?>" alt="<?= htmlspecialchars($product['name']) ?>" />
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <h5 class="fw-bolder"><?= htmlspecialchars($product['name']) ?></h5>
                                    <div class="price-text">
                                        RON: <?= number_format($product['price'], 2) ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center">
                                    <a class="btn btn-outline-dark mt-auto" href="#">
                                        <i class="bi-cart-fill me-1"></i> Add to cart
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website <?= date('Y') ?></p></div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>