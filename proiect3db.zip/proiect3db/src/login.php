<?php
// login.php
session_start();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (file_exists('data/users.xml')) {
        $xml = simplexml_load_file('data/users.xml');
        foreach ($xml->user as $user) {
            if ((string)$user->username === $username && (string)$user->password === $password) {
                $_SESSION['user'] = [
                    'username' => (string)$user->username,
                    'email' => (string)$user->email,
                    'role' => (string)$user->role
                ];

                if ($_SESSION['user']['role'] === 'admin') {
                    header('Location: admin.php');
                } else {
                    header('Location: shop.php');
                }
                exit();
            }
        }
    }

    $error = 'Utilizator sau parolă incorectă.';
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">
    <h1 class="mb-4">Autentificare</h1>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" class="w-50">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" name="username" id="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Parolă</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
        <a href="register.php" class="btn btn-link">Nu ai cont? Înregistrează-te</a>
    </form>
</body>
</html>
