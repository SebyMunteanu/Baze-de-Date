<?php
session_start();
require_once 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    $bulk = new MongoDB\Driver\BulkWrite;
    $id = new MongoDB\BSON\ObjectId($_POST['id']);
    $filter = ['_id' => $id];
    
    // Obține produsul pentru a șterge și imaginea asociată
    $query = new MongoDB\Driver\Query($filter);
    $product = current($client->executeQuery("my_shop_db.products", $query)->toArray());
    
    // Șterge imaginea din sistemul de fișiere dacă există
    if (!empty($product->imagine)) {
        $imagePath = __DIR__ . '/uploads/' . $product->imagine;
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }
    
    $bulk->delete($filter);
    $result = $client->executeBulkWrite('my_shop_db.products', $bulk);
    
    $_SESSION['toast'] = [
        'type' => 'success',
        'message' => 'Produsul a fost șters cu succes!'
    ];
    header('Location: index.php');
    exit;
}

$id = new MongoDB\BSON\ObjectId($_GET['id']);
$filter = ['_id' => $id];
$query = new MongoDB\Driver\Query($filter);
$product = current($client->executeQuery("my_shop_db.products", $query)->toArray());

if (!$product) {
    $_SESSION['toast'] = [
        'type' => 'danger',
        'message' => 'Produsul nu a fost găsit!'
    ];
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Ștergere Produs - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <style>
        .confirmation-card {
            max-width: 600px;
            margin: 2rem auto;
            border-left: 5px solid #dc3545;
        }
        .product-image {
            max-height: 200px;
            object-fit: contain;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="index.php">My Shop</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="bi bi-arrow-left"></i> Back to Shop
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Confirmation Section -->
    <section class="py-5">
        <div class="container">
            <div class="card confirmation-card">
                <div class="card-header bg-white">
                    <h2 class="card-title text-danger mb-0">
                        <i class="bi bi-exclamation-octagon-fill"></i> Confirmare ștergere
                    </h2>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <?php if (!empty($product->imagine)): ?>
                            <img src="<?= !empty($product->imagine) ? 'uploads/' . htmlspecialchars($product->imagine) : 'https://via.placeholder.com/300x200?text=No+Image' ?>" 
                                class="product-image img-thumbnail mb-3"
                                alt="<?= htmlspecialchars($product->nume) ?>"
                                onerror="this.src='https://via.placeholder.com/300x200?text=Image+Not+Found'">

                        <?php endif; ?>
                        <h4>Sigur doriți să ștergeți acest produs?</h4>
                    </div>
                    
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <li><strong>Name:</strong> <?= htmlspecialchars($product->nume) ?></li>
                            <li><strong>Price:</strong> <?= htmlspecialchars($product->pret) ?> RON</li>
                            <?php if (!empty($product->culoare)): ?>
                                <li><strong>Color:</strong> <?= htmlspecialchars($product->culoare) ?></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <form method="post">
                        <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
                        <div class="d-flex justify-content-center gap-3 mt-4">
                            <a href="index.php" class="btn btn-lg btn-outline-secondary flex-grow-1">
                                <i class="bi bi-x-circle"></i> Anulează
                            </a>
                            <button type="submit" name="confirm_delete" class="btn btn-lg btn-danger flex-grow-1">
                                <i class="bi bi-trash3-fill"></i> Șterge
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-4 bg-dark">
        <div class="container">
            <p class="m-0 text-center text-white">
                &copy; <?= date('Y') ?> Magazin Online. Toate drepturile rezervate.
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Toast Notification -->
    <?php if (isset($_SESSION['toast'])): ?>
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
        <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-<?= $_SESSION['toast']['type'] ?> text-white">
                <strong class="me-auto">Notificare</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?= $_SESSION['toast']['message'] ?>
            </div>
        </div>
    </div>
    <?php unset($_SESSION['toast']); endif; ?>
</body>
</html>