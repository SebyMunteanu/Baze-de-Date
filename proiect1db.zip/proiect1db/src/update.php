<?php
require_once 'connection.php';
require_once 'update_trigger.php';

try {
    // Eliminăm și recreăm procedura
    $con->exec("DROP PROCEDURE IF EXISTS updateProducts");
    $con->exec("
        CREATE PROCEDURE updateProducts(
            IN p_nume VARCHAR(80),
            IN p_detalii VARCHAR(80),
            IN p_pret INT,
            IN p_imagine Varchar(255)
        )
        BEGIN
            UPDATE products 
            SET nume = p_nume, detalii = p_detalii ,imagine = p_imagine
            WHERE pret = p_pret;
        END;
    ");
} catch (PDOException $e) {
    die("Error creating procedure: " . $e->getMessage());
}

// Procesăm formularul
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nume = $_POST['nume'];
    $detalii = $_POST['detalii'];
    $pret = (int)$_POST['pret']; // Convertim prețul la INT
    // Procesează încărcarea imaginii
    if (isset($_FILES['imagine']) && $_FILES['imagine']['error'] == 0) {
        $target_dir = "uploads/";
        
        // Verifică dacă folderul există; dacă nu, îl creează
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        // Generează un nume unic pentru fișier
        $unique_name = uniqid() . "_" . basename($_FILES["imagine"]["name"]);
        $target_file = $target_dir . $unique_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Verifică dacă fișierul este o imagine
        $check = getimagesize($_FILES["imagine"]["tmp_name"]);
        if ($check !== false) {
            // Verifică dimensiunea fișierului (de exemplu, maxim 5MB)
            if ($_FILES["imagine"]["size"] <= 5 * 1024 * 1024) {
                // Verifică tipul fișierului
                if (in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
                    // Încearcă să încarce fișierul
                    if (move_uploaded_file($_FILES["imagine"]["tmp_name"], $target_file)) {
                        $imagine = $target_file;
                    } else {
                        echo "<div class='alert alert-danger'>Sorry, there was an error uploading your file.</div>";
                    }
                } else {
                    echo "<div class='alert alert-danger'>Sorry, only JPG, JPEG, PNG, and GIF files are allowed.</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Sorry, your file is too large. Maximum size is 5MB.</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>File is not an image.</div>";
        }
    } else {
        // Dacă nu este încărcată o nouă imagine, păstrează imaginea existentă
        $imagine = null;
    }

    try {
        // Apelăm procedura stocată
        $stmt = $con->prepare("CALL updateProducts(?, ?, ?, ?)");
        $stmt->execute([$nume, $detalii, $pret, $imagine]);

        // Verificăm câte rânduri au fost afectate
        if ($stmt->rowCount() > 0) {
            echo "<div class='alert alert-success'>Update successfully!</div>";
        } else {
            echo "<div class='alert alert-warning'>No changes made. Either the price does not exist or the data is the same.</div>";
        }
    } catch (PDOException $e) {
        echo "<div class='alert alert-danger'>Error updating data: " . $e->getMessage() . "</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Update Product</h1>
        <form action="update.php" method="POST" enctype="multipart/form-data" class="mt-4">
            <div class="mb-3">
                <label for="nume" class="form-label">Nume:</label>
                <input type="text" name="nume" id="nume" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="detalii" class="form-label">Detalii:</label>
                <input type="text" name="detalii" id="detalii" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="pret" class="form-label">Pret (criteriu de actualizare):</label>
                <input type="number" name="pret" id="pret" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="imagine" class="form-label">Imagine nouă:</label>
                <input type="file" name="imagine" id="imagine" class="form-control" accept="image/*">
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
        <br/>
        <a href="index.php" class="btn btn-secondary">Back to Home</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
