<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';

// Procesează formularul
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $price = (float)$_POST['price'];
    $category = trim($_POST['category']);
    $stock = (int)$_POST['stock'];
    $description = trim($_POST['description']);

    // Procesează imaginea
    $imagePath = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'assets/products/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $destination = $uploadDir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
            $imagePath = $destination;
        } else {
            $error = 'Eroare la încărcarea imaginii!';
        }
    }

    if (!$error) {
        // Adaugă produsul în XML
        $xmlFile = 'data/products.xml';
        
        if (file_exists($xmlFile)) {
            $xml = simplexml_load_file($xmlFile);
        } else {
            $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><products></products>');
        }

        // Generează ID unic
        $id = uniqid();

        $product = $xml->addChild('product');
        $product->addAttribute('id', $id);
        $product->addChild('name', htmlspecialchars($name));
        $product->addChild('price', $price);
        $product->addChild('category', htmlspecialchars($category));
        $product->addChild('stock', $stock);
        $product->addChild('description', htmlspecialchars($description));
        
        if ($imagePath) {
            $product->addChild('image', $imagePath);
        }

        // Salvează XML
        $dom = new DOMDocument('1.0');
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;
        $dom->loadXML($xml->asXML());
        
        if ($dom->save($xmlFile)) {
            $success = 'Produs adăugat cu succes!';
        } else {
            $error = 'Eroare la salvarea produsului!';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adaugă Produs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .image-preview {
            max-width: 200px;
            max-height: 200px;
            display: none;
            margin-top: 10px;
        }
        .form-control:focus, .form-select:focus {
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }
    </style>
</head>
<body>
    <?php include('admin_nav.php'); ?>

    <main class="container-fluid py-4">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h2 class="h4 mb-0"><i class="bi bi-plus-circle"></i> Adaugă Produs Nou</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php elseif ($success): ?>
                            <div class="alert alert-success"><?= $success ?></div>
                        <?php endif; ?>

                        <form method="POST" enctype="multipart/form-data">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="name" class="form-label">Nume Produs</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="price" class="form-label">Preț (RON)</label>
                                    <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="category" class="form-label">Categorie</label>
                                    <select class="form-select" id="category" name="category" required>
                                        <option value="">Selectează categoria</option>
                                        <option value="Electronice">Electronice</option>
                                        <option value="Fashion">Fashion</option>
                                        <option value="Casă">Casă</option>
                                        <option value="Jucării">Jucării</option>
                                        <option value="Altele">Altele</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="stock" class="form-label">Stoc</label>
                                    <input type="number" class="form-control" id="stock" name="stock" value="0" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">Descriere</label>
                                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="image" class="form-label">Imagine Produs</label>
                                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                                <small class="text-muted">Încarcă o imagine pentru produs (JPEG, PNG, max 2MB)</small>
                                <img id="imagePreview" src="#" alt="Preview imagine" class="image-preview img-thumbnail">
                            </div>

                            <div class="d-flex justify-content-between">
                                <a href="admin_products.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-arrow-left"></i> Înapoi
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save"></i> Salvează Produs
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Previzualizare imagine
        document.getElementById('image').addEventListener('change', function(e) {
            const preview = document.getElementById('imagePreview');
            const file = e.target.files[0];
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        });
    </script>
</body>
</html>