<?php
session_start();

// Verifică dacă utilizatorul este admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Încarcă produsele din XML
$products = [];
if (file_exists('data/products.xml')) {
    $xml = simplexml_load_file('data/products.xml');
    foreach ($xml->product as $product) {
        $products[] = [
            'id' => (string)$product['id'],
            'name' => (string)$product->name,
            'price' => (float)$product->price,
            'category' => isset($product->category) ? (string)$product->category : 'N/A',
            'stock' => isset($product->stock) ? (int)$product->stock : 0
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Produse</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php include('admin_nav.php'); ?>

    <main class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="bi bi-box-seam"></i> Gestionează Produse</h1>
            <a href="admin_product_add.php" class="btn btn-success">
                <i class="bi bi-plus-lg"></i> Adaugă Produs
            </a>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Nume</th>
                                <th>Preț</th>
                                <th>Categorie</th>
                                <th>Stoc</th>
                                <th>Acțiuni</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?= $product['id'] ?></td>
                                <td><?= htmlspecialchars($product['name']) ?></td>
                                <td><?= number_format($product['price'], 2) ?> lei</td>
                                <td><?= htmlspecialchars($product['category']) ?></td>
                                <td>
                                    <span class="badge bg-<?= $product['stock'] > 0 ? 'success' : 'danger' ?>">
                                        <?= $product['stock'] ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="admin_product_edit.php?id=<?= $product['id'] ?>" 
                                       class="btn btn-sm btn-outline-primary me-1" title="Editează">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="admin_product_delete.php?id=<?= $product['id'] ?>" 
                                       class="btn btn-sm btn-outline-danger" title="Șterge"
                                       onclick="return confirm('Sigur vrei să ștergi acest produs?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>