<?php
session_start();

// Verifică dacă utilizatorul este admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Încarcă comenzile din XML
$orders = [];
if (file_exists('data/orders.xml')) {
    $xml = simplexml_load_file('data/orders.xml');
    foreach ($xml->order as $order) {
        $orders[] = [
            'id' => (string)$order['id'],
            'user' => (string)$order->client->name, // Schimbat din 'user' în 'client->name'
            'email' => (string)$order->client->email, // Adăugat email
            'date' => (string)$order['date'],
            'total' => (float)$order->total,
            'status' => (string)$order['status'],
            'products_count' => count($order->items->product) // Adăugat număr de produse
        ];
    }
}

// Sortează comenzile după dată (cele mai noi primele)
usort($orders, function($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});

// Procesare filtrare
$status_filter = $_GET['status'] ?? '';
$search_term = $_GET['search'] ?? '';

if ($status_filter) {
    $orders = array_filter($orders, function($order) use ($status_filter) {
        return strtolower($order['status']) === strtolower($status_filter);
    });
}

if ($search_term) {
    $orders = array_filter($orders, function($order) use ($search_term) {
        return stripos($order['user'], $search_term) !== false || 
               stripos($order['email'], $search_term) !== false ||
               stripos($order['id'], $search_term) !== false;
    });
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Comenzi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .status-pending { color: #d48806; }
        .status-completed { color: #389e0d; }
        .status-cancelled { color: #cf1322; }
        .order-row:hover { background-color: #f8f9fa; }
        .badge-status { font-size: 0.85em; }
    </style>
</head>
<body>
    <?php include('admin_nav.php'); ?>

    <main class="container-fluid py-4">
        <div class="d-flex justify-content-between flex-wrap align-items-center mb-4">
            <h1><i class="bi bi-receipt"></i> Gestionează Comenzi</h1>
            
            <!-- Formular filtrare -->
            <form method="get" class="row g-2">
                <div class="col-auto">
                    <input type="text" name="search" class="form-control" placeholder="Caută client sau ID..." 
                           value="<?= htmlspecialchars($search_term) ?>">
                </div>
                <div class="col-auto">
                    <select name="status" class="form-select">
                        <option value="">Toate stările</option>
                        <option value="în procesare" <?= $status_filter === 'în procesare' ? 'selected' : '' ?>>În procesare</option>
                        <option value="finalizată" <?= $status_filter === 'finalizată' ? 'selected' : '' ?>>Finalizate</option>
                        <option value="anulată" <?= $status_filter === 'anulată' ? 'selected' : '' ?>>Anulate</option>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-funnel"></i> Filtrează
                    </button>
                    <a href="admin_orders.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-counterclockwise"></i>
                    </a>
                </div>
            </form>
        </div>

        <!-- Card statistici rapide -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card border-primary">
                    <div class="card-body">
                        <h5 class="card-title">Comenzi totale</h5>
                        <p class="card-text display-6"><?= count($orders) ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-success">
                    <div class="card-body">
                        <h5 class="card-title">Finalizate</h5>
                        <p class="card-text display-6">
                            <?= count(array_filter($orders, fn($o) => $o['status'] === 'finalizată')) ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-warning">
                    <div class="card-body">
                        <h5 class="card-title">În procesare</h5>
                        <p class="card-text display-6">
                            <?= count(array_filter($orders, fn($o) => $o['status'] === 'în procesare')) ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabel comenzi -->
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Client</th>
                                <th>Dată</th>
                                <th>Total</th>
                                <th>Produse</th>
                                <th>Status</th>
                                <th>Acțiuni</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($orders)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">Nu s-au găsit comenzi</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($orders as $order): ?>
                                <tr class="order-row">
                                    <td>#<?= $order['id'] ?></td>
                                    <td>
                                        <?= htmlspecialchars($order['user']) ?>
                                        <br><small class="text-muted"><?= $order['email'] ?></small>
                                    </td>
                                    <td><?= date('d.m.Y', strtotime($order['date'])) ?></td>
                                    <td><?= number_format($order['total'], 2) ?> lei</td>
                                    <td><?= $order['products_count'] ?> produse</td>
                                    <td>
                                        <span class="badge rounded-pill badge-status bg-<?= 
                                            $order['status'] === 'finalizată' ? 'success' : 
                                            ($order['status'] === 'anulată' ? 'danger' : 'warning') 
                                        ?>">
                                            <?= ucfirst($order['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="admin_order_view.php?id=<?= $order['id'] ?>" 
                                           class="btn btn-sm btn-outline-primary me-1"
                                           title="Vezi detalii">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="order_update.php?id=<?= $order['id'] ?>&action=finalizeaza"
                                            class="btn btn-sm btn-outline-success"
                                            title="Marchează ca finalizată"
                                            onclick="return confirm('Sigur doriți să marcați această comandă ca finalizată?')">
                                            <i class="bi bi-check-circle"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Confirmare pentru marcarea ca finalizată
        document.querySelectorAll('.btn-outline-success').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                if (confirm('Sigur doriți să marcați această comandă ca finalizată?')) {
                    // Aici poți adăuga logica AJAX pentru actualizare
                    alert('Comandă marcată ca finalizată!');
                    window.location.reload();
                }
            });
        });
    </script>
</body>
</html>