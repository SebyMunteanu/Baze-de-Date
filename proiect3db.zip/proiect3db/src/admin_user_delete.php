<?php
session_start();

// Verifică dacă utilizatorul este admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$username = $_GET['username'] ?? '';

// Verifică dacă utilizatorul există
$userExists = false;
$xml = simplexml_load_file('data/users.xml');
foreach ($xml->user as $user) {
    if ((string)$user->username === $username) {
        $userExists = true;
        break;
    }
}

if (!$userExists) {
    header('Location: admin_users.php');
    exit();
}

// Procesează ștergerea
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nu permite ștergerea contului propriu
    if ($username === $_SESSION['user']['username']) {
        $_SESSION['error'] = 'Nu poți șterge contul tău propriu!';
        header('Location: admin_users.php');
        exit();
    }

    // Șterge utilizatorul
    $users = $xml->xpath("/users/user[username!='$username']");
    
    $newXml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><users></users>');
    foreach ($users as $user) {
        $newUser = $newXml->addChild('user');
        foreach ($user->children() as $child) {
            $newUser->addChild($child->getName(), (string)$child);
        }
    }

    // Salvează în fișier
    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($newXml->asXML());
    
    if ($dom->save('data/users.xml')) {
        $_SESSION['success'] = 'Utilizator șters cu succes!';
    } else {
        $_SESSION['error'] = 'Eroare la ștergerea utilizatorului!';
    }
    
    header('Location: admin_users.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Șterge Utilizator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php include('admin_nav.php'); ?>

    <main class="container-fluid py-4">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h2 class="h4 mb-0"><i class="bi bi-exclamation-triangle text-danger"></i> Confirmă ștergerea</h2>
                    </div>
                    <div class="card-body">
                        <p>Ești sigur că vrei să ștergi utilizatorul <strong><?= htmlspecialchars($username) ?></strong>?</p>
                        <p>Această acțiune este permanentă și nu poate fi anulată.</p>
                        
                        <form method="POST">
                            <div class="d-flex justify-content-between">
                                <a href="admin_users.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-x-circle"></i> Anulează
                                </a>
                                <button type="submit" class="btn btn-danger">
                                    <i class="bi bi-trash"></i> Șterge
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>