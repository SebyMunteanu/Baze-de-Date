<?php
// checkout.php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
    header('Location: login.php');
    exit();
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header('Location: cart.php');
    exit();
}

// Preluare produse
$products = [];
$total = 0;

if (file_exists('data/products.xml')) {
    $xml = simplexml_load_file('data/products.xml');
    foreach ($xml->product as $product) {
        $id = (string)$product['id'];
        if (isset($cart[$id])) {
            $products[$id] = [
                'name' => (string)$product->name,
                'price' => (float)$product->price,
                'quantity' => $cart[$id]
            ];
            $total += $cart[$id] * (float)$product->price;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
    <h1 class="mb-4">Finalizare comandă</h1>
    <a href="cart.php" class="btn btn-secondary mb-3">Înapoi la coș</a>

    <form action="place_order.php" method="post">
        <div class="mb-3">
            <label for="address" class="form-label">Adresă de livrare</label>
            <input type="text" name="address" id="address" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="method" class="form-label">Metodă de livrare</label>
            <select name="method" id="method" class="form-select" required>
                <option value="Curier rapid">Curier rapid</option>
                <option value="Curier standard">Curier standard</option>
                <option value="Ridicare personală">Ridicare personală</option>
            </select>
        </div>

        <h4>Produse comandate:</h4>
        <ul class="list-group mb-3">
            <?php foreach ($products as $prod): ?>
            <li class="list-group-item d-flex justify-content-between">
                <span><?= htmlspecialchars($prod['name']) ?> x <?= $prod['quantity'] ?></span>
                <span><?= number_format($prod['price'] * $prod['quantity'], 2) ?> lei</span>
            </li>
            <?php endforeach; ?>
            <li class="list-group-item d-flex justify-content-between">
                <strong>Total:</strong>
                <strong><?= number_format($total, 2) ?> lei</strong>
            </li>
        </ul>

        <button type="submit" class="btn btn-success">Plasează comanda</button>
    </form>
</body>
</html>