<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 d-md-block sidebar collapse bg-dark p-3">
            <div class="position-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Admin Panel</h4>
                    <hr class="bg-light">
                    <p class="text-muted small">Bun venit, <strong><?= htmlspecialchars($_SESSION['user']['username']) ?></strong></p>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="bi bi-speedometer2 me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'admin_users.php' ? 'active' : '' ?>" 
                           href="admin_users.php">
                            <i class="bi bi-people me-2"></i>Utilizatori
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'admin_products.php' ? 'active' : '' ?>" 
                           href="admin_products.php">
                            <i class="bi bi-box-seam me-2"></i>Produse
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'admin_orders.php' ? 'active' : '' ?>" 
                           href="admin_orders.php">
                            <i class="bi bi-receipt me-2"></i>Comenzi
                        </a>
                    </li>
                    <li class="nav-item mt-4">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">