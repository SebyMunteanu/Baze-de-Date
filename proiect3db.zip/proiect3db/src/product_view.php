<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
    header('Location: login.php');
    exit();
}

$productId = $_GET['id'] ?? '';
$product = null;

if (file_exists('data/products.xml')) {
    $xml = simplexml_load_file('data/products.xml');
    foreach ($xml->product as $p) {
        if ((string)$p['id'] === $productId) {
            $product = [
                'id' => (string)$p['id'],
                'name' => (string)$p->name,
                'price' => (float)$p->price,
                'image' => (string)$p->image,
                'description' => (string)$p->description,
                'category' => (string)$p->category,
                'stock' => (int)$p->stock
            ];
            break;
        }
    }
}

if (!$product) {
    echo '<p>Produsul nu a fost găsit.</p>';
    exit();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($product['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
    <a href="shop.php" class="btn btn-secondary mb-3">&larr; Înapoi la magazin</a>

    <div class="row">
        <div class="col-md-6">
            <img src="<?= htmlspecialchars($product['image']) ?>" class="img-fluid" alt="<?= htmlspecialchars($product['name']) ?>">
        </div>
        <div class="col-md-6">
            <h2><?= htmlspecialchars($product['name']) ?></h2>
            <p><strong>Preț:</strong> <?= number_format($product['price'], 2) ?> lei</p>
            <p><strong>Categorie:</strong> <?= htmlspecialchars($product['category']) ?></p>
            <p><strong>Stoc disponibil:</strong> <?= $product['stock'] ?></p>
            <p><strong>Descriere:</strong><br><?= nl2br(htmlspecialchars($product['description'])) ?></p>

            <form method="post" action="shop.php">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <button type="submit" class="btn btn-success">Adaugă în coș</button>
            </form>
        </div>
    </div>
</body>
</html>
