<?php
session_start();

// Verifică dacă utilizatorul este admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Încarcă utilizatorii din XML
$users = [];
if (file_exists('data/users.xml')) {
    $xml = simplexml_load_file('data/users.xml');
    foreach ($xml->user as $user) {
        $users[] = [
            'username' => (string)$user->username,
            'email' => (string)$user->email,
            'role' => (string)$user->role,
            'created_at' => isset($user->created_at) ? (string)$user->created_at : 'N/A'
        ];
    }
}

// Sortează utilizatorii după username
usort($users, function($a, $b) {
    return strcmp($a['username'], $b['username']);
});
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Utilizatori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .table-responsive { overflow-x: auto; }
        .role-admin { background-color: #e6f7ff; }
        .role-user { background-color: #f6ffed; }
    </style>
</head>
<body>
    <?php include('admin_nav.php'); ?>

    <main class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="bi bi-people"></i> Gestionează Utilizatori</h1>
            <a href="admin_user_add.php" class="btn btn-primary">
                <i class="bi bi-plus-lg"></i> Adaugă Utilizator
            </a>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Data Înregistrării</th>
                                <th>Acțiuni</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr class="role-<?= $user['role'] ?>">
                                <td><?= htmlspecialchars($user['username']) ?></td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td>
                                    <span class="badge bg-<?= $user['role'] === 'admin' ? 'primary' : 'secondary' ?>">
                                        <?= ucfirst($user['role']) ?>
                                    </span>
                                </td>
                                <td><?= $user['created_at'] ?></td>
                                <td>
                                    <a href="admin_user_edit.php?username=<?= urlencode($user['username']) ?>" 
                                       class="btn btn-sm btn-outline-primary me-1" title="Editează">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <?php if ($user['username'] !== $_SESSION['user']['username']): ?>
                                    <a href="admin_user_delete.php?username=<?= urlencode($user['username']) ?>" 
                                       class="btn btn-sm btn-outline-danger" title="Șterge"
                                       onclick="return confirm('Sigur vrei să ștergi acest utilizator?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>