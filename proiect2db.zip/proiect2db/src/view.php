<?php
require_once 'connection.php';

$id = new \MongoDB\BSON\ObjectID($_GET['id']);
$filter = ['_id' => $id];
$query = new MongoDB\Driver\Query($filter);
$article = $client->executeQuery("my_shop_db.products", $query);
$doc = current($article->toArray());

// Verifică dacă există imagine în baza de date
if (isset($doc->imagine) && !empty($doc->imagine)) {
    $imagePath = 'uploads/' . $doc->imagine;
    $productImage = file_exists($imagePath) ? $imagePath : 'https://dummyimage.com/600x700/dee2e6/6c757d.jpg';
} else {
    $productImage = 'https://dummyimage.com/600x700/dee2e6/6c757d.jpg';
}
?>

<!-- Restul codului rămâne la fel -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Detalii Produs - <?php echo htmlspecialchars($doc->nume); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <style>
        .product-details {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 0.5rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
        .product-image {
            max-height: 400px;
            object-fit: contain;
            width: 100%;
        }
        .debug-info {
            background-color: #f8f9fa;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            font-size: 14px;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="index.php">My Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item"><a class="nav-link" href="index.php">Back to Shop</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="py-5">
        <div class="container">
            <div class="product-details">
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo $productImage; ?>" 
                             alt="<?php echo htmlspecialchars($doc->nume); ?>" 
                             class="img-fluid product-image"
                             onerror="this.src='https://dummyimage.com/600x700/dee2e6/6c757d.jpg'">
                    </div>
                    <div class="col-md-6">
                        <h1 class="fw-bolder"><strong>Name:</strong> <?php echo htmlspecialchars($doc->nume); ?></h1>
                        <div class="fs-5 mb-3">
                            <span class="fw-bold"><strong>Price:</strong> <?php echo htmlspecialchars($doc->pret); ?> RON</span>
                        </div>
                        <p class="lead"><strong>Color:</strong> <?php echo htmlspecialchars($doc->culoare); ?></p>
                        <p class="lead"><strong>Size:</strong> <?php echo htmlspecialchars($doc->marime); ?></p>
                        <p class="lead"><strong>Age:</strong> <?php echo htmlspecialchars($doc->age); ?></p>
                        <p class="lead"><strong>Movie:</strong> <?php echo htmlspecialchars($doc->movie); ?></p>
                        <div class="d-flex mt-4">
                            <a href="index.php" class="btn btn-outline-secondary flex-shrink-0">
                                <i class="bi bi-arrow-left me-1"></i> Back
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="py-5 bg-dark">
        <div class="container"><p class="m-0 text-center text-white">Copyright &copy; My Shop 2023</p></div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>