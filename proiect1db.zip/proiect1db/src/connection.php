<?php
$dbms='mysql'; 
$host='mysql_db'; #localhost 
$db='my_shop_db';
$user='root';
$pass='toor';
$dsn="$dbms:host=$host;dbname=$db";
$con=new PDO($dsn, $user, $pass);

try {
    $con = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully!"; // Mesaj de debug
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}