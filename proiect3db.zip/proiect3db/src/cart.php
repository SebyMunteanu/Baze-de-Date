<?php
// cart.php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
    header('Location: login.php');
    exit();
}

$cart = $_SESSION['cart'] ?? [];
$products = [];
$total = 0;

if (file_exists('data/products.xml')) {
    $xml = simplexml_load_file('data/products.xml');
    foreach ($xml->product as $product) {
        $id = (string)$product['id'];
        if (isset($cart[$id])) {
            $products[$id] = [
                'name' => (string)$product->name,
                'price' => (float)$product->price,
                'image' => (string)$product->image,
                'quantity' => $cart[$id]
            ];
            $total += $cart[$id] * (float)$product->price;
        }
    }
}

if (isset($_GET['remove'])) {
    unset($_SESSION['cart'][$_GET['remove']]);
    header('Location: cart.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Coșul Meu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
    <h1 class="mb-4">🛒 Coșul tău</h1>
    <a href="shop.php" class="btn btn-secondary mb-3">Înapoi la magazin</a>

    <?php if (empty($products)): ?>
        <p>Coșul tău este gol.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Produs</th>
                    <th>Cantitate</th>
                    <th>Preț unitar</th>
                    <th>Total</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $id => $prod): ?>
                <tr>
                    <td><?= htmlspecialchars($prod['name']) ?></td>
                    <td><?= $prod['quantity'] ?></td>
                    <td><?= number_format($prod['price'], 2) ?> lei</td>
                    <td><?= number_format($prod['price'] * $prod['quantity'], 2) ?> lei</td>
                    <td><a href="cart.php?remove=<?= $id ?>" class="btn btn-danger btn-sm">Șterge</a></td>
                </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                    <td><strong><?= number_format($total, 2) ?> lei</strong></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
        <a href="checkout.php" class="btn btn-primary">Continuă la checkout</a>
    <?php endif; ?>
</body>
</html>