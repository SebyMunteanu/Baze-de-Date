<?php
// place_order.php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
    header('Location: login.php');
    exit();
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart) || !isset($_POST['address'], $_POST['method'])) {
    header('Location: checkout.php');
    exit();
}

$user = $_SESSION['user'];
$address = trim($_POST['address']);
$method = trim($_POST['method']);
$date = date('Y-m-d');
$status = 'în procesare';
$total = 0;

// Încărcare produse
$xmlProducts = simplexml_load_file('data/products.xml');
$selectedProducts = [];

foreach ($xmlProducts->product as $product) {
    $id = (string)$product['id'];
    if (isset($cart[$id])) {
        $price = (float)$product->price;
        $qty = $cart[$id];
        $selectedProducts[] = [
            'id' => $id,
            'name' => (string)$product->name,
            'price' => $price,
            'quantity' => $qty
        ];
        $total += $price * $qty;
    }
}

// Încărcare/salvare orders.xml
$ordersFile = 'data/orders.xml';
$ordersXml = file_exists($ordersFile) ? simplexml_load_file($ordersFile) : new SimpleXMLElement('<orders></orders>');

// Generează ID unic
$orderId = time();
$newOrder = $ordersXml->addChild('order');
$newOrder->addAttribute('id', $orderId);
$newOrder->addAttribute('date', $date);
$newOrder->addAttribute('status', $status);

$client = $newOrder->addChild('client');
$client->addChild('name', htmlspecialchars($user['username']));
$client->addChild('email', htmlspecialchars($user['email']));
$client->addChild('phone', '---'); // Poți extinde formularul pentru telefon

$shipping = $newOrder->addChild('shipping');
$shipping->addChild('address', htmlspecialchars($address));
$shipping->addChild('method', htmlspecialchars($method));

$items = $newOrder->addChild('items');
foreach ($selectedProducts as $prod) {
    $p = $items->addChild('product', htmlspecialchars($prod['name']));
    $p->addAttribute('id', $prod['id']);
    $p->addAttribute('quantity', $prod['quantity']);
    $p->addAttribute('price', $prod['price']);
}

$newOrder->addChild('total', number_format($total, 2, '.', ''));

// Salvează XML
$ordersXml->asXML($ordersFile);

// Golește coșul
unset($_SESSION['cart']);

// Redirecționează
header('Location: shop.php');
exit();