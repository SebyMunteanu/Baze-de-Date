<?php
require_once 'connection.php';
require_once 'delete_trigger.php';

// Procedura 
###
// Eliminam si recream procedura
$sql1="DROP PROCEDURE IF EXISTS deleteProducts";
$sql2="CREATE PROCEDURE deleteProducts(
    IN strNume VARCHAR(30)
)
BEGIN
    DELETE FROM products WHERE nume=strNume;
END";
$stmt1=$con->prepare($sql1);
$stmt2=$con->prepare($sql2);
$stmt1->execute();
$stmt2->execute();
###

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nume = $_POST['nume'];
try{
    // Obține calea imaginii din baza de date înainte de ștergere
    $sql = "SELECT imagine FROM products WHERE nume = :nume";
    $stmt = $con->prepare($sql);
    $stmt->execute([':nume' => $nume]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product && !empty($product['imagine'])) {
        // Șterge fișierul imagine din folderul uploads
        $image_path = $product['imagine'];
        if (file_exists($image_path)) {
            unlink($image_path); // Șterge fișierul
        }
    }
    $sql="CALL deleteProducts('{$nume}')";
    $stmt=$con->query($sql);
    $stmt->execute(['nume'=>$nume]);
    if ($stmt->rowCount() > 0) {
        echo "<div class='alert alert-success'>Produsul a fost șters cu succes!</div>";
    } else {
        echo "<div class='alert alert-warning'>Nu s-a găsit produsul cu numele specificat.</div>";
    }
}catch (PDOException $e) {
    echo "<div class='alert alert-danger'>Eroare la ștergerea produsului: " . $e->getMessage() . "</div>";
    }
    
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Product</title>
    <!-- Stiluri Bootstrap pentru un aspect mai frumos -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Delete Product</h1>
        <form action="delete.php" method="POST" class="mt-4">
            <div class="mb-3">
                <label for="nume" class="form-label">Nume:</label>
                <input type="text" name="nume" id="nume" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
        <br/>
        <a href="index.php" class="btn btn-secondary">Back to Home</a>
    </div>

    <!-- Scripturi Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

