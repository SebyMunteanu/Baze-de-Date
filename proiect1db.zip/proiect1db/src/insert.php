<?php
require_once 'connection.php';
require_once 'insert_trigger.php';
###
$sql1="DROP PROCEDURE IF EXISTS InsertProducts";
$sql2="CREATE PROCEDURE InsertProducts(
    IN strNume VARCHAR(30),
    IN strDetalii VARCHAR(30),
    IN intPret INT,
    IN strImagine VARCHAR(255)
)
BEGIN
    INSERT INTO products(nume,detalii,pret,imagine) VALUES (strNume, strDetalii, intPret,strImagine);
END";
$stmt1=$con->prepare($sql1);
$stmt2=$con->prepare($sql2);
$stmt1->execute();
$stmt2->execute();
###

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nume = $_POST['nume'];
    $detalii = $_POST['detalii'];
    $pret = $_POST['pret'];
    // Procesează încărcarea imaginii
    if (isset($_FILES['imagine']) && $_FILES['imagine']['error'] == 0) {
        $target_dir = "uploads/";
        
        // Verifică dacă folderul există; dacă nu, îl creează
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        // Generează un nume unic pentru fișier
        $unique_name = uniqid() . "_" . basename($_FILES["imagine"]["name"]);
        $target_file = $target_dir . $unique_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Verifică dacă fișierul este o imagine
        $check = getimagesize($_FILES["imagine"]["tmp_name"]);
        if ($check !== false) {
            // Verifică dimensiunea fișierului (de exemplu, maxim 5MB)
            if ($_FILES["imagine"]["size"] <= 5 * 1024 * 1024) {
                // Verifică tipul fișierului
                if (in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
                    // Încearcă să încarce fișierul
                    if (move_uploaded_file($_FILES["imagine"]["tmp_name"], $target_file)) {
                        $imagine = $target_file;
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                } else {
                    echo "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
                }
            } else {
                echo "Sorry, your file is too large. Maximum size is 5MB.";
            }
        } else {
            echo "File is not an image.";
        }
    } else {
        $imagine = null; // Sau o valoare implicită
    }

    $sql="CALL InsertProducts('{$nume}','{$detalii}','{$pret}','{$imagine}')";
    $q=$con->query($sql);
    if($q){
        echo "Insert successfully";
    }else{
        echo "Insert failed";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Insert Product</title>
    <!-- Stiluri Bootstrap pentru un aspect mai frumos -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Insert Product</h1>
        <form action="insert.php" method="POST" enctype="multipart/form-data" class="mt-4">
            <div class="mb-3">
                <label for="nume" class="form-label">Nume:</label>
                <input type="text" name="nume" id="nume" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="detalii" class="form-label">Detalii:</label>
                <input type="text" name="detalii" id="detalii" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="pret" class="form-label">Pret:</label>
                <input type="number" name="pret" id="pret" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="imagine" class="form-label">Imagine:</label>
                <input type="file" name="imagine" id="imagine" class="form-control" accept="image/*" required>
            </div>

            <button type="submit" class="btn btn-primary">Insert</button>
        </form>
        <br/>
        <a href="index.php" class="btn btn-secondary">Back to Home</a>
    </div>

    <!-- Scripturi Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>