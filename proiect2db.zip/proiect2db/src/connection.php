<?php
$client = new MongoDB\Driver\Manager("mongodb://root:toor@mongo:27017/");
#$cilent = new MongoDB\Driver\Manager("mongodb://localhost:27017");
?>