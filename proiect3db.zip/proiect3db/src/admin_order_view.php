<?php
$orderId = $_GET['id'] ?? '';
$order = null;

if (file_exists('data/orders.xml')) {
    $xml = simplexml_load_file('data/orders.xml');
    foreach ($xml->order as $o) {
        if ((string)$o['id'] === $orderId) {
            $order = [
                'id' => (string)$o['id'],
                'date' => (string)$o['date'],
                'status' => (string)$o['status'],
                'client' => [
                    'name' => (string)$o->client->name,
                    'email' => (string)$o->client->email,
                    'phone' => (string)$o->client->phone
                ],
                'items' => [],
                'total' => (float)$o->total,
                'shipping' => [
                    'address' => (string)$o->shipping->address,
                    'method' => (string)$o->shipping->method
                ]
            ];
            foreach ($o->items->product as $product) {
                $order['items'][] = [
                    'id' => (string)$product['id'],
                    'name' => (string)$product,
                    'quantity' => (int)$product['quantity'],
                    'price' => (float)$product['price']
                ];
            }
            break;
        }
    }
}

if (!$order) {
    header('Location: admin_orders.php');
    exit;
}
?>

<!-- Interfață detalii comandă -->
<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between">
            <h4>Comanda #<?= $order['id'] ?></h4>
            <span class="badge bg-<?= 
                $order['status'] === 'finalizată' ? 'success' : 
                ($order['status'] === 'anulată' ? 'danger' : 'warning') 
            ?>">
                <?= ucfirst($order['status']) ?>
            </span>
        </div>
        <div class="card-body">
            <!-- Detalii client -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <h5><i class="bi bi-person"></i> Client</h5>
                    <p>
                        <strong><?= $order['client']['name'] ?></strong><br>
                        <?= $order['client']['email'] ?><br>
                        Tel: <?= $order['client']['phone'] ?>
                    </p>
                </div>
                <div class="col-md-6">
                    <h5><i class="bi bi-truck"></i> Livrare</h5>
                    <p>
                        <?= $order['shipping']['address'] ?><br>
                        Metodă: <?= $order['shipping']['method'] ?>
                    </p>
                </div>
            </div>

            <!-- Produse -->
            <h5><i class="bi bi-cart"></i> Produse</h5>
            <table class="table">
                <thead>
                    <tr>
                        <th>Produs</th>
                        <th>Cantitate</th>
                        <th>Preț unitar</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($order['items'] as $item): ?>
                    <tr>
                        <td><?= $item['name'] ?> (ID: <?= $item['id'] ?>)</td>
                        <td><?= $item['quantity'] ?></td>
                        <td><?= number_format($item['price'], 2) ?> RON</td>
                        <td><?= number_format($item['price'] * $item['quantity'], 2) ?> RON</td>
                    </tr>
                    <?php endforeach; ?>
                    <tr class="table-light">
                        <td colspan="3" class="text-end"><strong>Total comandă:</strong></td>
                        <td><strong><?= number_format($order['total'], 2) ?> RON</strong></td>
                    </tr>
                </tbody>
            </table>

            <!-- Acțiuni -->
            <div class="d-flex justify-content-end gap-2 mt-4">
                <button class="btn btn-outline-secondary">
                    <i class="bi bi-printer"></i> Printează
                </button>
                <button class="btn btn-primary">
                    <i class="bi bi-check-circle"></i> Marchează ca finalizată
                </button>
            </div>
        </div>
    </div>
</div>