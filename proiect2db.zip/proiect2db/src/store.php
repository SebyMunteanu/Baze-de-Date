<?php
require_once 'connection.php';

// Crează directorul uploads dacă nu există
$uploadDir = __DIR__ . '/uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Procesează imaginea
$imageName = null;
if (isset($_FILES['imagine']) && $_FILES['imagine']['error'] === UPLOAD_ERR_OK) {
    $extension = pathinfo($_FILES['imagine']['name'], PATHINFO_EXTENSION);
    $imageName = uniqid() . '.' . $extension;
    $targetPath = $uploadDir . $imageName;
    
    // Verifică tipul fișierului
    $validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (in_array($_FILES['imagine']['type'], $validTypes)) {
        move_uploaded_file($_FILES['imagine']['tmp_name'], $targetPath);
    } else {
        $imageName = null; // Dacă tipul nu e valid
    }
}

// Salvează în baza de date
$bulk = new MongoDB\Driver\BulkWrite;
$data = [
    '_id' => new MongoDB\BSON\ObjectID,
    'nume' => $_POST['nume'],
    'culoare' => $_POST['culoare'],
    'marime' => $_POST['marime'],
    'pret' => (float)$_POST['pret'],
    'age' => $_POST['age'] ?? null,
    'movie' => $_POST['movie'] ?? null,
    'imagine' => $imageName // Salvează doar numele fișierului
];

$bulk->insert($data);
$client->executeBulkWrite('my_shop_db.products', $bulk);

header('Location: index.php');
exit;
?>